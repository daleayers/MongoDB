from pymongo import MongoClient
class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username="aacuser", password="Nirvana123rocks."):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        if username and password:
            self.client = MongoClient('mongodb://%s:%s@localhost:38104' % ("aacuser", "Nirvana123rocks."))
        else:
            self.client = MongoClient('mongodb://localhost:38104')
        self.database = self.client['AAC']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            insert = self.database.animals.insert(data)  
            if insert!=0:
                return True
            else:
                return False           
        else:
            raise Exception("Nothing to save")


    # Create method to implement the R in CRUD.
    def read(self,criteria=None):
        dogs = []
        if criteria:       
            data = self.database.animals.find(criteria,{"_id":False})
        else: 
            data = self.database.animals.find( {} , {"_id":False})
            
        for i in self.database.animals.find_one( criteria , {"_id":False}):
            dogs.append(i)


        return dogs